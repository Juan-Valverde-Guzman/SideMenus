// MenuViewController.swift
import UIKit

class MenuViewController: UIViewController {
    override func viewDidLoad() {
            super.viewDidLoad()
            setupUI()
        }

        func setupUI() {
            view.backgroundColor = .cyan // Color de fondo gris

            let button1 = UIButton(type: .system)
            button1.setTitle("Botón 1", for: .normal)
            button1.addTarget(self, action: #selector(button1Tapped), for: .touchUpInside)

            let button2 = UIButton(type: .system)
            button2.setTitle("Botón 2", for: .normal)
            button2.addTarget(self, action: #selector(button2Tapped), for: .touchUpInside)

            let stackView = UIStackView(arrangedSubviews: [button1, button2])
            stackView.axis = .vertical
            stackView.spacing = 20
            stackView.alignment = .leading
            stackView.translatesAutoresizingMaskIntoConstraints = false

            view.addSubview(stackView)

            NSLayoutConstraint.activate([
                stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                stackView.topAnchor.constraint(equalTo: view.topAnchor, constant: 100)
            ])
        }

        @objc func button1Tapped() {
            print("Botón 1 presionado")
        }

        @objc func button2Tapped() {
            print("Botón 2 presionado")
        }
}

// ViewController.swift
import UIKit

class ViewController: UIViewController {
    
    var menuViewController: MenuViewController?
    
    var isMenuVisible = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menuViewController = MenuViewController()
        
        addChild(menuViewController!)
        view.addSubview(menuViewController!.view)
        menuViewController!.didMove(toParent: self)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        view.addGestureRecognizer(panGesture)
        
        // Configura el menú lateral derecho
        setupRightMenu()
    }
    
    func setupRightMenu() {
        // Puedes configurar el menú lateral derecho de manera similar al izquierdo
        // Crea un nuevo controlador para el menú derecho y agrégalo como child view controller
    }
    
    @objc func handlePanGesture(_ recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: view)
        
        switch recognizer.state {
        case .changed:
            // Actualiza la posición del menú en función del gesto
            let isMovingRight = translation.x > 0
            menuViewController?.view.frame.origin.x = isMovingRight ? 0 : -menuWidth()
            
        case .ended:
            // Detecta si el menú debería mostrarse o ocultarse según la posición final del gesto
            let shouldShowMenu = menuViewController!.view.frame.origin.x > -menuWidth() / 2
            animateMenu(shouldShow: shouldShowMenu)
            
        default:
            break
        }
    }
    
    func animateMenu(shouldShow: Bool) {
        UIView.animate(withDuration: 0.3) {
            self.menuViewController?.view.frame.origin.x = shouldShow ? 0 : -self.menuWidth()
        }
        isMenuVisible = shouldShow
    }
    
    func menuWidth() -> CGFloat {
        return view.frame.width * 0.8 // Ajusta según tu diseño
    }
}
