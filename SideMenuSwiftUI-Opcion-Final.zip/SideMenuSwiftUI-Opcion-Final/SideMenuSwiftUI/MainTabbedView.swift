//
//  MainTabbedView.swift
//  SideMenuSwiftUI
//
//  Created by Zeeshan Suleman on 04/03/2023.
//

import SwiftUI

// En tu MainTabbedView
struct MainTabbedView: View {
    
    @State var presentSideMenuHome = false
    @State var presentSideMenuTab = 0
    @State var menu = 0
    @State private var presentAlert = false
    
    var body: some View {
        ZStack{
            TabView(selection: $presentSideMenuTab) {
                HomeView(presentSideMenu: $presentSideMenuHome, presentSideMenuTab: $presentSideMenuTab, menu: $menu)
                    .tag(0)
                SecondView(presentSideMenu: $presentSideMenuHome, presentSideMenuTab: $presentSideMenuTab, menu: $menu)
                    .tag(1)
            }
            
            SideMenu(isShowing: $presentSideMenuHome, menu: $menu, content: AnyView(SideMenuView(presentSideMenuTab: $presentSideMenuTab, presentSideMenu: $presentSideMenuHome, menu: $menu)))
        }
    }
}
