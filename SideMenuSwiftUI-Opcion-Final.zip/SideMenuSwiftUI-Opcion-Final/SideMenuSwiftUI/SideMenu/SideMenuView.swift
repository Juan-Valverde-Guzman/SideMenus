//
//  SideMenuView.swift
//  DripJobsTeams
//
//  Created by Zeeshan Suleman on 28/02/2023.
//

import SwiftUI

let alerta1 = "Primer alert"

let alerta2 = "Segunda alert"

enum SideMenuRowType: Int, CaseIterable{
    case home = 0
    case second
    case alert1
    case alert2
    case switchMenu
    
    var title: String{
        switch self {
        case .home:
            return "Home"
        case .second:
            return "Segunda Vista"
        case .alert1:
            return alerta1
        case .alert2:
            return alerta2
        case .switchMenu:
            return "Switch Menu"
        }
    }
    
    var iconName: String{
        switch self {
        case .home:
            return "home"
        case .second:
            return "favorite"
        case .alert1:
            return "profile"
        case .alert2:
            return "chat"
        case .switchMenu:
            return "chat"
        }
    }
}

struct SideMenuView: View {
    
    @Binding var presentSideMenuTab: Int
    @Binding var presentSideMenu: Bool
    @Binding var menu: Int
    @State private var currentMenuType: SideMenuType = .main
    @State private var showAlert = false
    @State private var alertas = 0
    
    var body: some View {
        HStack {
            
            //16 Spacer() y se me pone a la derecha
            
            if menu == 1 {
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
                Spacer()
                
            } else {
                
            }
            
            ZStack{
                Rectangle()
                    .fill(.white)
                    .frame(width: 270)
                    .shadow(color: .purple.opacity(0.1), radius: 5, x: 0, y: 3)
                
                VStack(alignment: .leading, spacing: 0) {
                    
                    /*ProfileImageView()
                        .frame(height: 140)
                        .padding(.bottom, 30)*/
                    
                    ForEach(getRows(for: currentMenuType), id: \.self){ row in
                        RowView(isSelected: presentSideMenuTab == row.rawValue, imageName: row.iconName, title: row.title) {
                            if row == .switchMenu {
                                
                                switchMenu()
                                
                            } else if row == .alert1 {
                                
                                /*let alert = UIAlertController(title: "esto", message: "es", preferredStyle: .alert)
                                
                                let okAction = UIAlertAction(title: "Ok", style: .cancel)
                                
                                alert.addAction(okAction)
                                
                                showAlert1.toggle()
                                
                                //alert1 = alert
                                
                                present(alert, animated: true)*/
                                
                                alertas = 0
                                
                                showAlert.toggle()
                                
                                //showAlert2 = false
                                
                            } else if row == .alert2 {
                             
                                alertas = 1
                                
                                showAlert.toggle()
                                
                                //showAlert1 = false
                                
                            } else {
                            
                                presentSideMenuTab = row.rawValue
                                presentSideMenu.toggle()
                            }
                        }
                    }
                    
                    Spacer()
                }
                .padding(.top, 100)
                .frame(width: 270)
                .background(
                    Color.white
                )
                
            }
            
            Spacer()
        }
        .background(.clear)
        /*.alert(isPresented: $showAlert1) {
            
            Alert(title: Text("Side menu derecho"), message: Text(alerta1), dismissButton: .cancel())
            
        }*/
        /*.alert(isPresented: $showAlert2) {
            
            Alert(title: Text("Side menu derecho"), message: Text(alerta2), dismissButton: .cancel())
            
        }*/
        
        .alert(isPresented: $showAlert) {
            
            switch alertas {
                
            case 0:
                
                return Alert(title: Text("Side menu derecho"), message: Text(alerta1), dismissButton: .cancel())
            case 1:
                
                return Alert(title: Text("Side menu derecho"), message: Text(alerta2), dismissButton: .cancel())
                
            default:
                
                return Alert(title: Text("Nose va a ver"), message: Text(alerta2), dismissButton: .cancel())
                
            }
            
        }
    }
    
    private func switchMenu() {
        
        currentMenuType = (currentMenuType == .main) ? .second : .main
        
    }
    
    private func getRows(for menuType: SideMenuType) -> [SideMenuRowType] {
        
        switch menuType {
            
        case .main:
            
            if menu == 0 {
                
                return SideMenuRowType.mainMenu
                
            } else if menu == 1 {
                
                return SideMenuRowType.secondMenu
                
            }
            
        case .second:
            
            if menu == 0 {
                
                return SideMenuRowType.mainMenu
                
            } else if menu == 1 {
                
                return SideMenuRowType.secondMenu
                
            }
            
        }
        
        return []
        
    }
    
    /*func ProfileImageView() -> some View{
        VStack(alignment: .center){
            HStack{
                Spacer()
                Image("profile-image")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 100)
                    .overlay(
                        RoundedRectangle(cornerRadius: 50)
                            .stroke(.purple.opacity(0.5), lineWidth: 10)
                    )
                    .cornerRadius(50)
                Spacer()
            }
            
            Text("Muhammad Abbas")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            Text("IOS Developer")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.black.opacity(0.5))
        }
    }*/
    
    func RowView(isSelected: Bool, imageName: String, title: String, hideDivider: Bool = false, action: @escaping (()->())) -> some View{
        Button{
            action()
        } label: {
            VStack(alignment: .leading){
                HStack(spacing: 20){
                    Rectangle()
                        .fill(isSelected ? .purple : .white)
                        .frame(width: 5)
                    
                    ZStack{
                        Image(imageName)
                            .resizable()
                            .renderingMode(.template)
                            .foregroundColor(isSelected ? .black : .gray)
                            .frame(width: 26, height: 26)
                    }
                    .frame(width: 30, height: 30)
                    Text(title)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(isSelected ? .black : .gray)
                    Spacer()
                }
            }
        }
        .frame(height: 50)
        .background(
            LinearGradient(colors: [isSelected ? .purple.opacity(0.5) : .white, .white], startPoint: .leading, endPoint: .trailing)
        )
    }
}

enum SideMenuType {
    
    case main
    
    case second
    
}

extension SideMenuRowType {
    
    static var mainMenu: [SideMenuRowType] {
        
        return [.home, .second/*, .switchMenu*/]
        
    }
    
    static var secondMenu: [SideMenuRowType] {
        
        return [.alert1, .alert2,/*, .switchMenu*/]
        
    }
    
}
