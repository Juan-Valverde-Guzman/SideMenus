//
//  SideMenu.swift
//  DripJobsTeams
//
//  Created by Zeeshan Suleman on 28/02/2023.
//

import SwiftUI

//El edgeTransition hace que salga el sidebar desde izquierda o derecha

struct SideMenu: View {
    @Binding var isShowing: Bool
    @Binding var menu: Int
    var content: AnyView
    var edgeTransition: AnyTransition {
        
        if menu == 0 {
            
            return .move(edge: .leading)
            
        } else {
            
            return .move(edge: .trailing)
            
        }
        
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            if (isShowing) {
                Color.black
                    .opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        isShowing.toggle()
                    }
                content
                    .transition(edgeTransition)
                    .background(
                        Color.clear
                    )
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
        .ignoresSafeArea()
        .animation(.easeInOut, value: isShowing)
    }
}
