//
//  FavoriteView.swift
//  SideMenuSwiftUI
//
//  Created by Zeeshan Suleman on 04/03/2023.
//

import SwiftUI

struct SecondView: View {
    
    @Binding var presentSideMenu: Bool
    @Binding var presentSideMenuTab: Int
    @Binding var menu: Int
    
    var body: some View {
        VStack{
            HStack{
                Button{
                    menu = 0
                    presentSideMenu.toggle()
                } label: {
                    Image("menu")
                        .resizable()
                        .frame(width: 32, height: 32)
                }
                Spacer()
                
                Button{
                    menu = 1
                    presentSideMenu.toggle()
                    
                } label: {
                    
                    Image("profile")
                        .resizable()
                        .frame(width: 32, height: 32)
                        .rotationEffect(.degrees(180))
                    
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                Spacer()
            }
            
            Spacer()
            Text("Second View")
            Spacer()
        }
        .padding(.horizontal, 24)
    }
}
